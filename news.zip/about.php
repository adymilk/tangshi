 <!DOCTYPE html>
 <html>
 <head>
 	<title>关于本站|古诗词检索系统</title>
 	<?php include './comm/head.php';?>
 </head>
 <body>
 
 </body>
 </html>