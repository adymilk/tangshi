<?php 
define('HOST', 'localhost');
define('USER', 'root');
define('PASSWORD', 'root');
define('DATABASE', '17601322524');
define('CHAR', 'utf8');

 ?>